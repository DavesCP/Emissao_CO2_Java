public interface MostrarDados {
    public void imprimirDados();
}